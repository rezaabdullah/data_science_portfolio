from .PointDistance import GeodesicPoints
from .PointDistance import EuclideanPoints