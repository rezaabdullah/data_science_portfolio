from setuptools import setup

setup(name = "pointdistance",
        version = "0.0.1",
        description = "Find distance between points",
        packages = ["pointdistance"],
        author = "Abdullah Reza",
        zip_safe = False)